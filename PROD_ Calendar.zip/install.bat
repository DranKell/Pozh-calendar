@echo off
chcp 65001 >nul
echo.
echo ===================================================
echo   Установка компонентов «Календарь ТО»
echo ===================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ОШИБКА] Python не найден! Установите Python 3.10+ и добавьте его в PATH.
    pause
    exit /b 1
)

echo [1/3] Обновление pip...
python -m pip install --upgrade pip --retries 5 --timeout 30

echo.
echo [2/3] Установка зависимостей из requirements.txt...
python -m pip install --prefer-binary -r requirements.txt --retries 5 --timeout 30

if %errorlevel% neq 0 (
    echo.
    echo [ПРЕДУПРЕЖДЕНИЕ] Стандартный сервер недоступен. Пробуем быстрое зеркало...
    python -m pip install --prefer-binary -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
)

echo.
echo [3/3] Инициализация справочника (seed.py)...
python seed.py

echo.
echo ===================================================
echo   Все компоненты успешно установлены!
echo   Для запуска используйте: run.bat или python run.py
echo ===================================================
echo.
pause
