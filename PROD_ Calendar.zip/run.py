# -*- coding: utf-8 -*-
import json
from pathlib import Path

import uvicorn

cfg = json.loads((Path(__file__).parent / "config.json").read_text(encoding="utf-8"))
port = int(cfg.get("server", {}).get("port", 9000))

if __name__ == "__main__":
    print()
    print("  КАЛЕНДАРЬ ТО · умный календарь ТО")
    print("  ->  http://localhost:%d" % port)
    print()
    uvicorn.run("app.main:app", host="127.0.0.1", port=port, reload=False)
